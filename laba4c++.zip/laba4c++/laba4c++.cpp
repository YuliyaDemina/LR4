﻿#include <iostream>
#include <math.h>
using namespace std;
float fun(float x)
{
	float f;
	f = (tan(x) + sin(x)) / exp(x);
	return f;
}
int main()
{
	int i;
	float x = 0;
	int n = 11;
	float arr[11];
	for (i = 0; i <n; i ++)
	{
		arr[i] = fun(x);
		cout << "x[" << i << "] = " << x << endl;
		x += 0.1;
	}
	cout << "\nResult arr:\n";
	for (int i = 0; i < n; i++) {
		cout << "arr[" << i << "] = " << arr[i] << endl;//вывод на экран
	}
	return 0;
}

